#include "for_gcc_build.hh" // only for gcc, TinyC will ignore it.

int main() {
	int n;
	"asdfsdf
	&
	$

}
